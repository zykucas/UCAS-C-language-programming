#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "chess.h"


int AttackScore(int x, int y, int Myside) //���������
{
	int score;

	if (Board[SIZE - x][y - 'A'] <= 10)
	{
			if (Myside == 1)
			{
				score=  winnerjudger(x,y,Myside)*800000
						+ ActiveFourJudger_nospace(x,y,Myside)* 300000
						+ ActiveFourJudger_onespace(x, y, Myside) * 80000
						+ ActiveThreeJudger_nospace(x, y, Myside) * 50000
					    + (ActiveThreeJudger_onespace(x, y, Myside) + RunFourJudger(x, y, Myside))*30000
						+ threefour(x, y, Myside) * 150000 
						+ (ActiveTwoJudger_nospace(x, y, Myside)+ SleepThreeJudger(x, y, Myside)) * 2000
						+  ActiveTwoJudger_onespace(x, y, Myside) * 500
						- (threethree(x, y, Myside) + fourfour(x, y, Myside) + LongConnect(x, y, Myside)) * 1500000;

				return score;
			}
			else
			{
				score=  (winnerjudger(x,y,Myside) + LongConnect(x, y, Myside))*800000
						+ ActiveFourJudger_nospace(x, y, Myside) * 300000
						+ ActiveFourJudger_onespace(x, y, Myside) * 80000
					    + ActiveThreeJudger_nospace(x, y, Myside) * 50000
						+ (RunFourJudger(x, y, Myside) + ActiveThreeJudger_onespace(x, y, Myside))*30000
					    + (threefour(x, y, Myside)  + fourfour(x, y, Myside) ) * 300000
						+ threethree(x, y, Myside)*100000
						+ (ActiveTwoJudger_nospace(x, y, Myside)+ SleepThreeJudger(x, y, Myside))* 2000
						+  ActiveTwoJudger_onespace(x, y, Myside) * 500;
				return score;
			}
	}
	else
	{
		return -10000; //�����������Ѿ����ӵ�λ��
	}
	
	
}

int DefendScore(int x, int y, int Myside)  //������ط�
{
	int score;


	if (Board[SIZE - x][y - 'A'] <= 10)
	{
		if (Myside == 1)
		{
			score=  (winnerjudger(x,y,Myside-1) + LongConnect(x, y, Myside - 1))*400000
					+ ActiveFourJudger_nospace(x,y,Myside-1)*180000
					+ ActiveFourJudger_onespace(x, y, Myside-1)*70000
					+ ActiveThreeJudger_nospace(x, y, Myside - 1)*45000
					+ (RunFourJudger(x, y, Myside - 1) + ActiveThreeJudger_onespace(x, y, Myside - 1))*27000
					+ (threefour(x, y, Myside - 1) + threethree(x, y, Myside - 1) + fourfour(x, y, Myside - 1) ) * 180000 
				    + (ActiveTwoJudger_nospace(x, y, Myside - 1) + SleepThreeJudger(x, y, Myside - 1))*1000
					+  ActiveTwoJudger_onespace(x, y, Myside - 1)*500
					- (threethree(x, y, Myside) + fourfour(x, y, Myside) + LongConnect(x, y, Myside)) * 1500000;
			return score;
		}
		else
		{
			score=	winnerjudger(x,y,Myside+1)*400000
					+ ActiveFourJudger_nospace(x, y, Myside + 1) * 180000
					+ ActiveFourJudger_onespace(x, y, Myside + 1) * 70000
					+ ActiveThreeJudger_nospace(x, y, Myside + 1) * 45000
					+ (RunFourJudger(x, y, Myside + 1) + ActiveThreeJudger_onespace(x, y, Myside + 1)) *27000
					+ threefour(x, y, Myside + 1) * 180000 
					+ (ActiveTwoJudger_nospace(x, y, Myside + 1) + SleepThreeJudger(x, y, Myside + 1)) * 1000
					+ ActiveTwoJudger_onespace(x, y, Myside + 1) * 500
				    - (threethree(x, y, Myside + 1) + fourfour(x, y, Myside + 1) + LongConnect(x, y, Myside + 1)) * 1500000;
			return score;
		}   
	
	}
	else
	{
		return -10000;
	}
	                                                           

}