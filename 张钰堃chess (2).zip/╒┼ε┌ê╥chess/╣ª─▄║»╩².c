#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "chess.h"

int search(int x, int y, int direction, int MySide, int jump)  //����������
{
	extern int Endpoint[2][2][2];
	extern int space;
	int RivalPoint = 0, RivalPointtem = 0;
	int MyPoint = 0, MyPointtem = 0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	int m = 0, n = 0;
	switch (direction)//�ĸ�����ķ�������
	{
	case 100:
		m = 1;
		n = 0;
		break;

	case 200:
		m = 0;
		n = 1;
		break;

	case 300:
		m = 1;
		n = -1;
		break;

	case 400:
		m = 1;
		n = 1;
		break;

	default:
		break;
	}

	int i = 1, j = 1;
	int space1 = 0, space2 = 0;
	int SerialNumber1 = 0, SerialNumber2 = 0;

	if (jump == 0)  //�����������ո�
	{
		while (Board[SIZE - (x + m * i)][y + n * i - 'A'] != RivalPoint && Board[SIZE - (x + m * i)][y + n * i - 'A'] != RivalPointtem && (SIZE - (x + m * i)) >= 0 && (SIZE - (x + m * i)) <= 14 && (y + n * i - 'A') >= 0 && (y + n * i - 'A') <= 14 && Board[SIZE - (x + m * i)][y + n * i - 'A'] >=10)
		{
			++SerialNumber1;
			i++;
		}
		while (Board[SIZE - (x - m * j)][y - n * j - 'A'] != RivalPoint && Board[SIZE - (x - m * j)][y - n * j - 'A'] != RivalPointtem && (SIZE - (x - m * j)) >= 0 && (SIZE - (x - m * j)) <= 14 && (y - n * j - 'A') >= 0 && (y - n * j - 'A') <= 14 && Board[SIZE - (x - m * j)][y - n * j - 'A'] >=10)
		{
			++SerialNumber2;
			j++;
		}
		Endpoint[0][0][0] = SIZE - (x + i * m);
		Endpoint[0][0][1] = y + i * n - 'A';
		Endpoint[0][1][0] = SIZE - (x - j * m);
		Endpoint[0][1][1] = y - j * n - 'A';
		Endpoint[1][0][0] = SIZE - (x + (i + 1) * m);
		Endpoint[1][0][1] = y + (i + 1) * n - 'A';
		Endpoint[1][1][0] = SIZE - (x - (j + 1) * m);
		Endpoint[1][1][1] = y - (j + 1) * n - 'A';  //����߽�����
	} 
	else if (jump == 1)//��������һ���ո�
	{
		while (Board[SIZE - (x + m * i)][y + n * i - 'A'] != RivalPoint && Board[SIZE - (x + m * i)][y + n * i - 'A'] != RivalPointtem && (SIZE - (x + m * i)) >= 0 && (SIZE - (x + m * i)) <= 14 && (y + n * i - 'A') >= 0 && (y + n * i - 'A') <= 14 )
		{
			if (Board[SIZE - (x + m * i)][y + n * i - 'A'] < 10 && space1 == 0 && (Board[SIZE - (x + m * (i+1))][y + n * (i+1) - 'A'] == MyPoint || Board[SIZE - (x + m * (i + 1))][y + n * (i + 1) - 'A'] == MyPointtem))
			{
				++space1;
				i++;
			}
			else if (Board[SIZE - (x + m * i)][y + n * i - 'A'] == MyPoint || Board[SIZE - (x + m * i)][y + n * i - 'A'] == MyPointtem)
			{ 
				++SerialNumber1;
				i++;
			}
			else
			{
				break;
			}

		}
		while (Board[SIZE - (x - m * j)][y - n * j - 'A'] != RivalPoint && Board[SIZE - (x - m * j)][y - n * j - 'A'] != RivalPointtem && (SIZE - (x - m * j)) >= 0 && (SIZE - (x - m * j)) <= 14 && (y - n * j - 'A') >= 0 && (y - n * j - 'A') <= 14)
		{
			if (Board[SIZE - (x - m * j)][y - n * j - 'A'] < 10 && space1 == 0 && (Board[SIZE - (x - m * (j + 1))][y - n * (j + 1) - 'A'] == MyPoint || Board[SIZE - (x - m * (j + 1))][y - n * (j + 1) - 'A'] == MyPointtem))
			{
				++space2;
				j++;
			}
			else if (Board[SIZE - (x - m * j)][y - n * j - 'A'] == MyPoint || Board[SIZE - (x - m * j)][y - n * j - 'A'] == MyPointtem)
			{
				++SerialNumber2;
				j++;
			}
			else
			{
				break;
			}

		}
	
		Endpoint[0][0][0] = SIZE - (x + i * m);
		Endpoint[0][0][1] = y + i * n - 'A';
		Endpoint[0][1][0] = SIZE - (x - j * m);
		Endpoint[0][1][1] = y - j * n - 'A';
		Endpoint[1][0][0] = SIZE - (x + (i + 1) * m);
		Endpoint[1][0][1] = y + (i + 1) * n - 'A';
		Endpoint[1][1][0] = SIZE - (x - (j + 1) * m);
		Endpoint[1][1][1] = y - (j + 1) * n - 'A';
	}
	if (space1 + space2 == 1)
	{
		space = 1;
		return SerialNumber1 + SerialNumber2;
	}
	else if (space1 + space2 == 0)
	{
		space = 0;
		return SerialNumber1 + SerialNumber2;
	}
	else
	{
		return 0;
	}
}



int border(int x,int  y)  //�ж������Ƿ�Խ��
{
	if (x < 0 || x>14 || y < 0 || y>14)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


//������������������������ո�
int ActiveThreeJudger_nospace(int x, int y, int MySide) {

	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveThreeNumber = 0;

	int RivalPoint = 0, RivalPointtem = 0;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 0);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i*100, MySide, 0) == 2 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			if (!((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && (Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem)))
			{
				if (border(x_endpoint2_1, y_endpoint2_1) * border(x_endpoint2_2, y_endpoint2_2) == 0)
				{
					if (!(((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && border(x_endpoint2_2, y_endpoint2_2) == 1) || ((Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem) && border(x_endpoint2_1, y_endpoint2_1) == 1)))
					{
						++ActiveThreeNumber;
					}
				}
			}
		}
	}
	
	return ActiveThreeNumber;


}



//���������������������һ���ո�
int ActiveThreeJudger_onespace(int x, int y, int MySide) {

	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveThreeNumber = 0;

	int RivalPoint = 0, RivalPointtem = 0;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 1);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 1) == 2 && space == 1 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			if (!((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && (Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem)))
			{
				if (border(x_endpoint2_1, y_endpoint2_1) * border(x_endpoint2_2, y_endpoint2_2) == 0)
				{
					if (!(((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && border(x_endpoint2_2, y_endpoint2_2) == 1) || ((Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem) && border(x_endpoint2_1, y_endpoint2_1) == 1)))
					{
						++ActiveThreeNumber;
					}
				}
			}
		}
	}

	return ActiveThreeNumber;


}



//�ж���������
int threethree(int x, int y, int MySide)
{
	if (ActiveThreeJudger_nospace(x, y, MySide)+ ActiveThreeJudger_onespace(x, y, MySide) >= 2)
	{
		return 1;

	}
	else
	{
		return 0;

	}
}


//������ĸ����������������ո�
int ActiveFourJudger_nospace(int x, int y, int MySide)
{
	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveFourNumber = 0;

	int RivalPoint, RivalPointtem;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 0);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 0) == 3 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			++ActiveFourNumber;
			
		}
	}

	return ActiveFourNumber;
}




//������ĸ�������������һ���ո�
int ActiveFourJudger_onespace(int x, int y, int MySide)
{
	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveFourNumber = 0;

	int RivalPoint, RivalPointtem;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 1);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 1) == 3 && space==1 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			++ActiveFourNumber;

		}
	}

	return ActiveFourNumber;
}




//������ĸ���
int RunFourJudger(int x, int y,  int MySide)
{
	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int RunFourNumber = 0;
	
	int RivalPoint = 0, RivalPointtem = 0;

	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	
	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 1);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i*100, MySide, 1) == 3 && ((Board[x_endpoint1_1][y_endpoint1_1] < 10 && (Board[x_endpoint1_2][y_endpoint1_2] == RivalPoint || Board[x_endpoint1_2][y_endpoint1_2] == RivalPointtem)) || (Board[x_endpoint1_2][y_endpoint1_2] < 10 && (Board[x_endpoint1_1][y_endpoint1_1] == RivalPoint || Board[x_endpoint1_1][y_endpoint1_1] == RivalPointtem))))
		{
			++RunFourNumber;

		}
	}

	return RunFourNumber;
}


//�ж����Ľ���
int fourfour(int x, int y, int MySide)
{
	if (ActiveFourJudger_nospace(x, y, MySide) + ActiveFourJudger_onespace(x, y, MySide) + RunFourJudger(x, y, MySide) >= 2)
	{
		return 1;

	}
	else
	{
		return 0;

	}
}



//�����������������������ո�
int ActiveTwoJudger_nospace(int x, int y, int MySide) {

	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveTwoNumber = 0;

	int RivalPoint = 0, RivalPointtem = 0;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 0);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 0) == 1 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			if (!((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && (Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem)))
			{
				if (border(x_endpoint2_1, y_endpoint2_1) * border(x_endpoint2_2, y_endpoint2_2) == 0)
				{
					if (!(((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && border(x_endpoint2_2, y_endpoint2_2) == 1) || ((Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem) && border(x_endpoint2_1, y_endpoint2_1) == 1)))
					{
						++ActiveTwoNumber;
					}
				}
			}
		}
	}

	if (ActiveTwoNumber <= 1)
	{
		return ActiveTwoNumber;
	}
	else if (ActiveTwoNumber >= 2)
	{
		return ActiveTwoNumber * 3;  //�ر�ע��˫���
	}
	


}



//��������������������һ���ո�
int ActiveTwoJudger_onespace(int x, int y, int MySide) {

	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int ActiveTwoNumber = 0;

	int RivalPoint = 0, RivalPointtem = 0;

	extern int space;
	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 1);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 1) == 1 && space==1 && Board[x_endpoint1_1][y_endpoint1_1] < 10 && Board[x_endpoint1_2][y_endpoint1_2] < 10)
		{
			if (!((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && (Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem)))
			{
				if (border(x_endpoint2_1, y_endpoint2_1) * border(x_endpoint2_2, y_endpoint2_2) == 0)
				{
					if (!(((Board[x_endpoint2_1][y_endpoint2_1] == RivalPoint || Board[x_endpoint2_1][y_endpoint2_1] == RivalPointtem) && border(x_endpoint2_2, y_endpoint2_2) == 1) || ((Board[x_endpoint2_2][y_endpoint2_2] == RivalPoint || Board[x_endpoint2_2][y_endpoint2_2] == RivalPointtem) && border(x_endpoint2_1, y_endpoint2_1) == 1)))
					{
						++ActiveTwoNumber;
					}
				}
			}
		}
	}

	if (ActiveTwoNumber <= 1)
	{
		return ActiveTwoNumber;
	}
	else if (ActiveTwoNumber >= 2)
	{
		return ActiveTwoNumber * 3;
	}



}


//������������
int SleepThreeJudger(int x, int y, int direction, int MySide)
{
	int x_endpoint1_1, y_endpoint1_1, x_endpoint1_2, y_endpoint1_2, x_endpoint2_1, y_endpoint2_1, x_endpoint2_2, y_endpoint2_2;
	int SleepThreeNumber = 0;

	int RivalPoint = 0, RivalPointtem = 0;

	if (MySide == 1)
	{
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	for (int i = 1; i <= 4; i++)
	{
		search(x, y, i * 100, MySide, 1);
		x_endpoint1_1 = Endpoint[0][0][0], y_endpoint1_1 = Endpoint[0][0][1];
		x_endpoint1_2 = Endpoint[0][1][0], y_endpoint1_2 = Endpoint[0][1][1];
		x_endpoint2_1 = Endpoint[1][0][0], y_endpoint2_1 = Endpoint[1][0][1];
		x_endpoint2_2 = Endpoint[1][1][1], y_endpoint2_2 = Endpoint[1][1][1];

		if (search(x, y, i * 100, MySide, 1) == 2 && ((Board[x_endpoint1_1][y_endpoint1_1] < 10 && (Board[x_endpoint1_2][y_endpoint1_2] == RivalPoint || Board[x_endpoint1_2][y_endpoint1_2] == RivalPointtem)) || (Board[x_endpoint1_2][y_endpoint1_2] < 10 && (Board[x_endpoint1_1][y_endpoint1_1] == RivalPoint || Board[x_endpoint1_1][y_endpoint1_1] == RivalPointtem))))
		{
			++SleepThreeNumber;
					
		}
	}
	
	return SleepThreeNumber;

}


//�ж����ģ�������Ҫ��ʤ�Ĺؼ�������
int threefour(int x,int y ,int MySide)
{
		if (ActiveFourJudger_nospace(x, y, MySide) + ActiveFourJudger_onespace(x, y, MySide) + RunFourJudger(x, y, MySide) >= 1)
		{
			if (ActiveThreeJudger_nospace(x, y,MySide) + ActiveThreeJudger_onespace(x, y, MySide) >= 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;

		}
}



//�жϳ�������
int LongConnect(int x, int y, int MySide)
{

	int array[4] = { 0, 0, 0, 0 };

	for (int i = 1; i <= 4; i++)
	{

		if (search(x, y, i * 100, MySide, 0) >= 5)
		{
			array[i - 1] = 1;
		}

	}

	int arr = 0;
	for (int i = 0; i < 4; i++)
	{
		arr = arr + array[i];
	}

	if (arr >= 1)
	{
		return 1;
	}
	else
	{
		return 0;
	}

}

