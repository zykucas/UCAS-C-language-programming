#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "chess.h"

int winnerjudger(int x, int y, int MySide)
{
	int MyPoint = 0, MyPointtem = 0;
	int RivalPoint = 0, RivalPointtem = 0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	int five = 0;

	for (int i = 1; i <= 4; i++)
	{
		if (search(x, y, i * 100, MySide, 0) == 4)
		{
			five = five + 1;
		}
	}  //����Ƿ�������

	if (five >= 1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
