#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define SIZE 15
#define BLACKtem 10
#define WHITEtem 11
#define BLACK 20
#define WHITE 21

int Board[SIZE][SIZE];

void InitBoardArray();  //��ʼ��������
void DisplayBoard();	//��ʾ����
int search();  //�ж�������
int border();  //�жϱ߽�
int ActiveThreeJudger();  //�жϻ���
int threethree();  //�ж���������
int ActiveFourJudger();  //�жϻ���
int RunFourJudger();  //�жϳ���
int fourfour();  //�ж����Ľ���
int LongConnect();  //�жϳ�������
int winnerjudger();  //�ж��Ƿ��γ�����

void main()
{
	char y;
	int x;

	InitBoardArray();
	DisplayBoard();

	for (int i = 0; i < 120; i++) {

		scanf("%c%d", &y, &x);  //�����Ļ���������
		getchar();

		

		if ((Board[SIZE - x][y - 'A'] != BLACK) && (Board[SIZE - x][y - 'A'] != WHITE) && (Board[SIZE - x][y - 'A'] != BLACKtem) && (Board[SIZE - x][y - 'A'] != WHITEtem)) 
		{
			if (winnerjudger(x, y, 1) == 1)
			{
				DisplayBoard();
				printf("You win.");
				
			}
			else if (threethree(x, y, 1) + fourfour(x, y, 1) + LongConnect(x, y, 1) >= 1)
			{
				DisplayBoard();
				printf("You are forbidden");
				
			}
			else
			{
				Board[SIZE - x][y - 'A'] = BLACK;//�ı������Ӧ����ֵ	
				
				DisplayBoard();	//��ʾ����
				
			}
		}

		else
		{
			printf("error");
		}


		scanf("%c%d", &y, &x);
		getchar();

		if ((Board[SIZE - x][y - 'A'] != BLACK) && (Board[SIZE - x][y - 'A'] != WHITE) && (Board[SIZE - x][y - 'A'] != BLACKtem) && (Board[SIZE - x][y - 'A'] != WHITEtem))
		{
			if (winnerjudger(x, y, 0) == 1)
			{
				printf("You win.");
			}
			else if (threethree(x, y, 0) + fourfour(x, y, 0) + LongConnect(x, y, 0) >= 1)
			{
				printf("You are forbidden");
			}
			else
			{
				Board[SIZE - x][y - 'A'] = WHITE;//�ı������Ӧ����ֵ	
				DisplayBoard();	//��ʾ����
			}
		}

		else
		{
			printf("error");
		}



	}
}



void InitBoardArray()
{
	int j, i;

	Board[0][0] = 1;
	Board[0][SIZE - 1] = 2;
	Board[SIZE - 1][SIZE - 1] = 3;
	Board[SIZE - 1][0] = 4;

	for (j = 1; j <= SIZE - 2; j++)
	{
		Board[j][0] = 5;
	}

	for (i = 1; i <= SIZE - 2; i++)
	{
		Board[0][i] = 6;
	}

	for (j = 1; j <= SIZE - 2; j++)
	{
		Board[j][SIZE - 1] = 7;
	}

	for (i = 1; i <= SIZE - 2; i++)
	{
		Board[SIZE - 1][i] = 8;
	}

	for (j = 1; j <= SIZE - 2; j++)
	{
		for (i = 1; i <= SIZE - 2; i++)
		{
			Board[j][i] = 9;
		}

	}
}

void DisplayBoard()
{
	int i, j;
	char line;
	char ary;

	system("cls");   //����

	for (j = 0, line = 15; j <= SIZE - 1; j++)
	{
		printf("%2d", line);
		line -= 1;
		for (i = 0; i <= SIZE - 1; i++)
		{
			switch (Board[j][i])
			{
			case 1:
				printf("��");
				break;

			case 2:
				printf("��");
				break;

			case 3:
				printf("��");
				break;

			case 4:
				printf("��");
				break;

			case 5:
				printf("��");
				break;

			case 6:
				printf("��");
				break;

			case 7:
				printf("��");
				break;

			case 8:
				printf("��");
				break;

			case 9:
				printf("��");
				break;

			case BLACKtem:      // ������һ��
				printf("��");
				break;

			case WHITEtem:      //������һ��
				printf("��");
				break;

			case BLACK:      //����ͨ��
				printf("��");
				break;

			case WHITE:
				printf("��");  //����ͨ��
				break;
			}
			if (i == SIZE - 1)
			{
				printf("\n");
			}

		}
	}

	printf("   ");
	for (ary = 'A'; ary < 'A' + SIZE; ary++)
		printf("%c ", ary);

	printf("\n");
}


int north_south = 100;
int west_east = 200;
int northeast_southwest = 300;
int northwest_southeast = 400;

int DxEndpoint1_1 = 0;
int DyEndpoint1_1 = 0;
int DxEndpoint1_2 = 0;
int DyEndpoint1_2 = 0;
int DxEndpoint2_1 = 0;
int DyEndpoint2_1 = 0;
int DxEndpoint2_2 = 0;
int DyEndpoint2_2 = 0;

int search(int x, int y, int direction, int MySide, int jump)
{

	int MyPoint=0, MyPointtem=0;
	int RivalPoint=0, RivalPointtem=0;
	int DxEndpoint1_1 = 0;
	int DyEndpoint1_1 = 0;
	int DxEndpoint1_2 = 0;
	int DyEndpoint1_2 = 0;
	int DxEndpoint2_1 = 0;
	int DyEndpoint2_1 = 0;
	int DxEndpoint2_2 = 0;
	int DyEndpoint2_2 = 0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	int m=0, n=0;
	switch (direction)//�ĸ�����ķ�������
	{
	case 100:
		m = 1;
		n = 0;
		break;

	case 200:
		m = 0;
		n = 1;
		break;

	case 300:
		m = 1;
		n = -1;
		break;

	case 400:
		m = 1;
		n = 1;
		break;

	default:
		break;
	}

	int i = 1, j = 1;
	int space1 = 0, space2 = 0;
	int SerialNumber1 = 0, SerialNumber2 = 0;

	if (jump == 0)  //�����������ո�
	{
		while ((Board[SIZE - (x + m * i)][y + n * i - 'A'] == MyPoint || Board[SIZE - (x + m * i)][y + n * i - 'A'] == MyPointtem) && (SIZE - (x + m * i)) >= 0 && (SIZE - (x + m * i)) <= 14 && (y + n * i - 'A') >= 0 && (y + n * i - 'A') <= 14)
		{
			++SerialNumber1;
			i++;
		}
		while ((Board[SIZE - (x - m * j)][y - n * j - 'A'] == MyPoint || Board[SIZE - (x - m * j)][y - n * j - 'A'] == MyPointtem) && (SIZE - (x - m * j)) >= 0 && (SIZE - (x - m * j)) <= 14 && (y - n * j - 'A') >= 0 && (y - n * j - 'A') <= 14)
		{
			++SerialNumber2;
			j++;
		}
		DxEndpoint1_1 = SIZE - (x + (i+1) * m);
		DyEndpoint1_1 = y + (i+1) * n-'A';
		DxEndpoint1_2 = SIZE - (x - (i+1) * m);
		DyEndpoint1_2 = y - (i+1) * n - 'A';
		DxEndpoint2_1 = SIZE - (x + (i+2) * m);
		DyEndpoint2_1 = y + (i+2) * n - 'A';
		DxEndpoint2_2 = SIZE - (x - (i+2) * m);
		DyEndpoint2_2 = y - (i+2) * n - 'A';
	}
	else if (jump == 1)//��������һ���ո�
	{
		while ((Board[SIZE-(x + m * i)][y + n * i-'A'] != RivalPoint && Board[SIZE - (x + m * i)][y + n * i - 'A'] != RivalPointtem) && !((Board[SIZE-(x + m * i)][y + n * i-'A'] < 10) && space1 == 1) && (SIZE-(x + m * i)) >= 0 && (SIZE-(x + m * i)) <= 14 && (y + n * i-'A') >= 0 && (y + n * i-'A') <= 14)
		{
			if (Board[SIZE-(x + m * i)][y + n * i-'A'] == MyPoint || Board[SIZE - (x + m * i)][y + n * i - 'A']==MyPointtem)
			{
				++SerialNumber1;
				i++;
			}
			else if (Board[SIZE-(x + m * i)][y + n * i-'A'] < 10 && space1 == 0)
			{
				++space1;
				i++;
			}
			else
			{
				i++;
			}

		}
		while ((Board[SIZE-(x - m * j)][y - n * j-'A'] != RivalPoint && Board[SIZE - (x - m * j)][y - n * j - 'A'] != RivalPointtem) && !((Board[SIZE-(x - m * j)][y - n * j-'A'] < 10) && space2 == 1) && (SIZE-(x - m * j)) >= 0 && (SIZE-(x - m * j)) <= 14 && (y - n * j-'A') >= 0 && (y - n * j-'A') <= 14)
		{
			if (Board[SIZE-(x - m * j)][y - n * j-'A'] == MyPoint || Board[SIZE - (x - m * j)][y - n * j - 'A'] == MyPointtem)
			{
				++SerialNumber2;
				j++;
			}
			else if (Board[SIZE-(x - m * j)][y - n * j-'A'] < 10 && space2 == 0)
			{
				++space2;
				j++;
			}
			else
			{
				j++;
			}

		}
		space1 = space1 - 1;
		space2 = space2 - 1;
		DxEndpoint1_1 = SIZE - (x + i * m);
		DyEndpoint1_1 = y +  1 * n - 'A';
		DxEndpoint1_2 = SIZE - (x - i  * m);
		DyEndpoint1_2 = y - i  * n - 'A';
		DxEndpoint2_1 = SIZE - (x + (i + 1) * m);
		DyEndpoint2_1 = y + (i + 1) * n - 'A';
		DxEndpoint2_2 = SIZE - (x - (i + 1) * m);
		DyEndpoint2_2 = y - (i + 1) * n - 'A';
	}
	if (space1 + space2 <= 1)
	{
		return SerialNumber1 + SerialNumber2;
	}
	else
	{
		return 0;
	}
}

int border(x, y)
{
	if (x < 0 || x>14 || y < 0 || y>14)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int ActiveThreeJudger(int x, int y, int direction, int MySide) {

	int MyPoint = 0, MyPointtem = 0;
	int RivalPoint = 0, RivalPointtem = 0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	int m = 0, n = 0;
	switch (direction)
	{
	case 100:
		m = 1;
		n = 0;
		break;

	case 200:
		m = 0;
		n = 1;
		break;

	case 300:
		m = 1;
		n = -1;
		break;

	case 400:
		m = 1;
		n = 1;
		break;

	default:
		break;
	}

	//�����������ж�
	search(x, y, direction, MySide, 1);
	if (search(x, y, direction, MySide, 1) == 2 && Board[DxEndpoint1_1][DyEndpoint1_1] < 10 && Board[DxEndpoint1_2][DyEndpoint1_2] < 10)
	{
		if (!((Board[DxEndpoint2_1][DyEndpoint2_1] == RivalPoint || Board[DxEndpoint2_1][DyEndpoint2_1] == RivalPointtem) && (Board[DxEndpoint2_2][DyEndpoint2_1] == RivalPoint || Board[DxEndpoint2_2][DyEndpoint2_1] == RivalPointtem)))
		{
			if (border(DxEndpoint2_1, DyEndpoint2_1) * border(DxEndpoint2_2, DyEndpoint2_2) == 0)
			{
				if (!(((Board[DxEndpoint2_1][DyEndpoint2_1] == RivalPoint || Board[DxEndpoint2_1][DyEndpoint2_1] == RivalPointtem) && border(DxEndpoint2_2, DyEndpoint2_2) == 1) || ((Board[DxEndpoint2_2][DyEndpoint2_2] == RivalPoint || Board[DxEndpoint2_2][DyEndpoint2_2] == RivalPointtem) && border(DxEndpoint2_1, DyEndpoint2_1) == 1)))
				{
					return 1;
				}
			}
		}
	}
	else
	{
		return 0;
	}


}

int threethree(int x, int y, int MySide)
{
	if (ActiveThreeJudger(x, y, 100, MySide) + ActiveThreeJudger(x, y, 200, MySide) + ActiveThreeJudger(x, y, 300, MySide) + ActiveThreeJudger(x, y, 400, MySide) >= 2)
	{
		return 1;

	}
	else 
	{
		return 0;

	}
}

int ActiveFourJudger(int x, int y, int direction, int MySide)
{
	int m=0, n=0;
	switch (direction)
	{
	case 100:
		m = 1;
		n = 0;
		break;

	case 200:
		m = 0;
		n = 1;
		break;

	case 300:
		m = 1;
		n = -1;
		break;

	case 400:
		m = 1;
		n = 1;
		break;

	default:
		break;
	}

	int MyPoint, MyPointtem;
	int RivalPoint, RivalPointtem;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	search(x, y, direction, MySide, 1);
	if (search(x, y, direction, MySide, 1) == 3 && Board[DxEndpoint1_1][DyEndpoint1_1] < 10 && Board[DxEndpoint1_2][DyEndpoint1_2] < 10)
	{
		 return 1;	
	
	}
	else
	{
		return 0;
	}
	
}

int RunFourJudger(int x, int y, int direction, int MySide)
{
	int m=0, n=0;
	switch (direction)
	{
	case 100:
		m = 1;
		n = 0;
		break;

	case 200:
		m = 0;
		n = 1;
		break;

	case 300:
		m = 1;
		n = -1;
		break;

	case 400:
		m = 1;
		n = 1;
		break;

	default:
		break;
	}

	int MyPoint=0, MyPointtem=0;
	int RivalPoint=0, RivalPointtem=0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	search(x, y, direction, MySide, 1);
	if (search(x, y, direction, MySide, 1) == 3 &&( (Board[DxEndpoint1_1][DyEndpoint1_1] < 10 && (Board[DxEndpoint1_2][DyEndpoint1_2] == RivalPoint || Board[DxEndpoint1_2][DyEndpoint1_2] == RivalPointtem))|| (Board[DxEndpoint1_2][DyEndpoint1_2] < 10 &&( Board[DxEndpoint1_1][DyEndpoint1_1] == RivalPoint || Board[DxEndpoint1_1][DyEndpoint1_1] == RivalPointtem))))
	{
		
		return 1;
		
	}
	else
	{
		return 0;
	}

}

int fourfour(int x, int y, int MySide)
{
	if (ActiveFourJudger(x, y, 100, MySide) + ActiveFourJudger(x, y, 200, MySide) + ActiveFourJudger(x, y, 300, MySide) + ActiveFourJudger(x, y, 400, MySide) + RunFourJudger(x, y, 100, MySide) + RunFourJudger(x, y, 200, MySide) + RunFourJudger(x, y, 300, MySide) + RunFourJudger(x, y, 400, MySide) >= 2)
	{
		return 1;

	}
	else
	{
		return 0;

	}
}

int LongConnect(int x,int y,int MySide)
{
	
	int array[4] = {0, 0, 0, 0};
	
	for (int i = 1; i <= 4; i++)
	{
		
		if (search(x,y,i*100,MySide,0) >= 5)
		{
			array[i - 1] = 1;
		}
		
	}

	int arr = 0;
	for (int i = 0; i < 4; i++)
	{
		arr = arr + array[i];
	}

	if (arr >= 1)
	{
		return 1;
	}
	else
	{
		return 0;
	}

}

int winnerjudger(x, y, MySide)
{
	int MyPoint = 0, MyPointtem = 0;
	int RivalPoint = 0, RivalPointtem = 0;

	if (MySide == 1)
	{
		MyPoint = BLACK;
		MyPointtem = BLACKtem;
		RivalPoint = WHITE;
		RivalPointtem = WHITEtem;
	}
	else if (MySide == 0)
	{
		MyPoint = WHITE;
		MyPointtem = WHITEtem;
		RivalPoint = BLACK;
		RivalPointtem = BLACKtem;
	}

	int five = 0;

	for (int i = 1; i <= 4; i++)
	{
		if (search(x, y, i * 100, MySide, 0) == 4)
		{
			five = five + 1;
		}
	}

	if (five >= 1) 
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
